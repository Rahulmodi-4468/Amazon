package com.stpl.demo.maven;
import javax.persistence.*;
@Entity
@DiscriminatorValue("contact")
public class Contactnumber  extends Student{
	private String perminant_number;
	private String emergency_number;
	public String getPerminant_number() {
		return perminant_number;
	}
	public void setPerminant_number(String perminant_number) {
		this.perminant_number = perminant_number;
	}
	public String getEmergency_number() {
		return emergency_number;
	}
	public void setEmergency_number(String emergency_number) {
		this.emergency_number = emergency_number;
	}
	
}
