package com.stpl.demo.maven;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "project started!" );
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory factory = cfg.buildSessionFactory();
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        
        
        Student st = new Student();
        st.setId(102);
        st.setName("WaytoWeb");
        st.setCity("Ahmedabad");
        System.out.println(st);
        Address ad = new Address();
        ad.setFlatNo("d1");
        ad.setAddress1("vasanseri");
        ad.setAddress2("saraspur");
        ad.setPincode(380016);
        
        Contactnumber cn = new Contactnumber();
        cn.setPerminant_number("1234567890");
        cn.setPerminant_number("7878454512");
        
        
        session.persist(st);
        session.persist(ad);
        session.persist(cn);
        
        session.save(st);
        tx.commit();
        session.close();
    }
}
