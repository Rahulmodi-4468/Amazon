package com.stpl.mapping;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HQLDemo {

	public static void main(String args[]) {
		System.out.println("Hibernate Query language Demp!");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session s = factory.openSession();
		Transaction tx = s.beginTransaction();

		//Fetch Data from table using HQL
		fetchData(s);

		//Delete Data from table using HQL
		//deleteData(s);

		//Fetch Data from table using HQL
		//fetchData(s);

		//Update Data in table
		Query q3 = s.createQuery("update Employee set name=:n where name='Suresh'");
		q3.setParameter("n", "Rahul");
		int r = q3.executeUpdate();
		System.out.println("Updated rows : " + r);
		
		tx.commit();
		s.close();
		factory.close();

	}

	public static void fetchData(Session s) {
		System.out.println("--------------------------------");
		System.out.println("  Get data from table using HQL");
		System.out.println("--------------------------------");

		String query = "from Employee";
		Query q1 = s.createQuery(query);
		List<Employee> list = q1.list();

		for (Employee e : list) {
			System.out.println(e.getName());
		}
	}
	
	public static void deleteData(Session s) {
		System.out.println("--------------------------------");
		System.out.println("   Delete Operation using HQL");
		System.out.println("--------------------------------");

		Query q2 = s.createQuery("delete from Employee where id=:id");
		q2.setParameter("id", 39);
		int r = q2.executeUpdate();
		System.out.println("Deleted : " + r);
	}
}
