package com.stpl.eventmanagement.core.controller;
import java.util.List;
import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.persistence.IEntityManager;

public interface IUserManager extends IEntityManager<User> {
	public void getUsersByDOB(String year);
	public List<User> getUsersByName(String name);
	public List<User> getAll();
	public Boolean validateUser(User user);
	public void save(User record);
	public int getPlaceIdByUserid(int userId);
	public void delete(User record);	
	public void getUsersByEvent(String eventName);
}
