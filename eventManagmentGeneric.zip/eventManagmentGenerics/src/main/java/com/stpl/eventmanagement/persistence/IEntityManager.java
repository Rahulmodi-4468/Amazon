package com.stpl.eventmanagement.persistence;

import java.util.List;

import com.stpl.eventmanagement.core.bean.User;


public interface IEntityManager<IEntityType> {
    
	public void save(IEntityType record);
    public IEntityType getById(Integer id);
    public void delete(IEntityType record);
    public List<IEntityType> getAll();

}
