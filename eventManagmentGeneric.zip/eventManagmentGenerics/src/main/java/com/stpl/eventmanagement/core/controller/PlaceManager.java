package com.stpl.eventmanagement.core.controller;

import java.util.List;

import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.core.dao.IPlaceDAO;
import com.stpl.eventmanagement.persistence.EntityManager;

public class PlaceManager extends EntityManager<Place, IPlaceDAO> implements IPlaceManager {

	public Place getPlaceByCity(String city) {

		Place place = new Place();
		List<Place> places = dao.getAll();

		for (Place p : places) {
			if (p.getCity().equals(city)) {
				place.setId(p.getId());
				place.setCity(p.getCity());
				break;
			}

		}
		return place;
	}

	public boolean validatePlace(Place place) {

		Place places = getPlaceByCity(place.getCity());
		if (places.getCity() == null) {
			return true;
		} else {
			return false;
		}

	}
	
	public void save(Place record) {
		boolean flag = validatePlace(record);

		if (flag != false) {
			System.out.println("saved place");
			dao.save(record);
		} else {
			System.out.print(" is already available.");
		}
	}

	@Override
	public void updatePlace(int placeId, String placeName) {
		System.out.println("------------------------");
		System.out.println("      Update Mode");
		System.out.println("------------------------");

		List<Place> places = getAll();
		
		Place savedPlace = getById(placeId);
		
		int inFlag = 0;
		Boolean failMsg = false;
		for (Place place : places) {
			if (place.getId() == placeId) {
				
				if ((place.getCity().equals(placeName))) {
					System.out.println("Place is already updated.");
					inFlag=0;
					failMsg = false;
					break;
				} else {
					inFlag = 1;
					failMsg = false;
					break;
				}
			} else {
				failMsg = true;
			}
		}
		if (inFlag == 1) {
			savedPlace.setCity(placeName);
			dao.save(savedPlace);
			System.out.println("Place Updated");
		}
		if (failMsg == true) {
			System.out.println("Place ID not Found.");
		}
	}
}
