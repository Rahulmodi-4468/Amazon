package com.stpl.eventmanagement.core.dao;

import java.util.List;

import com.stpl.eventmanagement.core.bean.Event;
import com.stpl.eventmanagement.persistence.IEntityDAO;

public interface IEventDAO extends IEntityDAO<Event>{

	public List<Event> getEventsByCityName(String city);
	public void save(Event record);

}
