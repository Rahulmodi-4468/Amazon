package com.stpl.eventmanagement.core.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.core.dao.IUserDAO;
import com.stpl.eventmanagement.persistence.EntityManager;

public class UserManager extends EntityManager<User, IUserDAO> implements IUserManager {

	@Autowired
	protected IPlaceManager placeManager;
	
	@Autowired
	protected IEventManager eventManager;
	
	@Autowired
	protected IUserEventManager userEventManager;

	public void getUsersByDOB(String year) {

		List<User> list = dao.getUsersByDOB(year);
		
		System.out.println(list.size());
		if (list.size() > 0) {
			System.out.println("--------------------------");
			System.out.println("   Name  : DOB");
			System.out.println("--------------------------");
			for (User user : list) {
				System.out.println("  " + user.getName() + " : " + user.getDOB());
			}
			System.out.println("---------------------------");
		} else {
			System.out.println("No user found with DOB having year : " + year);
		}
	}

	public List<User> getUsersByName(String name) {
		return getUsersByName(name);
	}

	public void save(User record) {
		Boolean flag = validateUser(record);

		if (flag != false) {
			dao.save(record);
		}
	}

	public int getPlaceIdByUserid(int userId) {

		int userCityId = 0;
		List<User> users = dao.getAll();

		for (User u : users) {
			if (u.getId().equals(userId)) {
				userCityId = u.getPlace().getId();
				break;
			}

		}
		return userCityId;
	}

	public Boolean validateUser(User user) {
		Boolean flag = true;
		String userName = user.getName();

//		String userDOB = user.getDOB();

		String cityOfUser = user.getCity();

		Place place = placeManager.getPlaceByCity(cityOfUser);

		if (place.getCity() == null) {
			Place places = new Place();
			places.setCity(cityOfUser);
			placeManager.save(places);
			user.setPlace(places);
		} else {
			user.setPlace(place);
		}

		List<User> userList = getAll();

		if (userList.size() >= 1) {
			for (int i = 0; i < userList.size(); i++) {
				String DBUserName = userList.get(i).getName();
				String DBUserCity = userList.get(i).getPlace().getCity();

				if ((userName.toLowerCase().equals(DBUserName.toLowerCase()))
						&& (cityOfUser.toLowerCase().equals(DBUserCity.toLowerCase()))) {
					System.out.print(DBUserName);

					assertEquals("User Name not matching", userName, DBUserName);

					flag = false;
				}
			}
			if (flag == true) {
				System.out.println("User Saved Successfully.");
				flag = true;
			}

		} else {
			System.out.println("new User");
			flag = true;

		}
		return flag;
	}

	@Override
	public void getUsersByEvent(String eventName) {
		int eventId = eventManager.getEventIdByName(eventName);
		List<Integer> userList = userEventManager.getUsersByEventId(eventId);
		
		System.out.println("-------------------------------------------------");
		System.out.println("User List who subscribe "+ eventName + " event.");
		System.out.println("-------------------------------------------------");

		for(Integer i : userList) {
			User user = getById(i);
			System.out.println("     "+user.getId()+" : "+user.getName());
		}
		System.out.println("-------------------------------------------------");
		
	}

}
