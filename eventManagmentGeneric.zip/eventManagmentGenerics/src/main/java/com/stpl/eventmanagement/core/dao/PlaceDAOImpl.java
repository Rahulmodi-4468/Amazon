package com.stpl.eventmanagement.core.dao;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.persistence.EntityDAOImpl;

public class PlaceDAOImpl extends EntityDAOImpl<Place> implements IPlaceDAO {

	@Override
	public Class<Place> getTargetClass() {
		return Place.class;
	}


	@Override
	public boolean isCityAvailable(String city) {
		boolean flag = true;
		Session currentSession = getHibernateTemplate().getSessionFactory().getCurrentSession();
		String sql = "SELECT EXISTS(SELECT * FROM eventdb.place WHERE city =" + city + ")";
		SQLQuery query = currentSession.createSQLQuery(sql);
		query.addEntity(Place.class);

		System.out.println("sql : "+sql);
	
		return flag;

	}
	public void save(Place record) {
		super.save(record);
	}


}
