package com.stpl.eventmanagement.core.dao;

import com.stpl.eventmanagement.core.bean.User_Events;
import com.stpl.eventmanagement.persistence.IEntityDAO;

public interface IUserEventDAO extends IEntityDAO<User_Events>{
	public void save(User_Events record);
}
