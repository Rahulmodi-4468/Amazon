package com.stpl.eventmanagement.core.dao;

import java.util.List;

import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.core.bean.User_Events;
import com.stpl.eventmanagement.persistence.EntityDAOImpl;

public class UserEventDAOImpl extends EntityDAOImpl<User_Events> implements IUserEventDAO {
	
	@Override
	public Class<User_Events> getTargetClass() {
		return User_Events.class;
	}

	public void save(User_Events record) {
		System.out.println("saved");
		super.save(record);
	}

	@Override
	public List<User> getUsersByDOB(String year) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> getUsersByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
