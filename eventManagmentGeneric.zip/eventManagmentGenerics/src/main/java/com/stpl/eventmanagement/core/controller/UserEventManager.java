package com.stpl.eventmanagement.core.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.stpl.eventmanagement.core.bean.Event;
import com.stpl.eventmanagement.core.bean.User_Events;
import com.stpl.eventmanagement.core.dao.IUserEventDAO;
import com.stpl.eventmanagement.persistence.EntityManager;

public class UserEventManager extends EntityManager<User_Events, IUserEventDAO> implements IUserEventManager {

	@Autowired
	protected IUserManager userManager;

	@Autowired
	protected IEventManager eventManager;

	public void save(User_Events record) {
		Boolean flag = validateUsersEvent(record.getUser_id(), record.getEvent_id());

		if (flag != false) {
			System.out.println("IN manager is true: ");
			dao.save(record);
		} else {
			System.out.println("Not mached");
		}

	}

	public boolean validateUsersEvent(int userId, int eventId) {

		int userPlaceId = userManager.getPlaceIdByUserid(userId);

		int eventPlaceId = eventManager.getPlaceIdByEventid(eventId);

		if (userPlaceId == eventPlaceId) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public List<Integer> getUsersByEventId(int eventId) {
		List<Integer> userList = new ArrayList<Integer>();
		List<User_Events> List = getAll();
		for(User_Events obj : List) {
			if(obj.getEvent_id() == eventId) {
				userList.add(obj.getUser_id());
			}
		}
		return userList;
	}

}
