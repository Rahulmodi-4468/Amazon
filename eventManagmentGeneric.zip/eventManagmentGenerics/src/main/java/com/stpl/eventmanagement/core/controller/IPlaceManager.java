package com.stpl.eventmanagement.core.controller;

import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.persistence.IEntityManager;

public interface IPlaceManager extends IEntityManager<Place> {
	 public Place getPlaceByCity(String city); 
	 public void save(Place record);
	 public boolean validatePlace(Place place);
     public void updatePlace(int placeId, String placeName);
}
