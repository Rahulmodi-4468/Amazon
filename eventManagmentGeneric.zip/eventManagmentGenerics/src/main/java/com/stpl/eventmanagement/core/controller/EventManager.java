package com.stpl.eventmanagement.core.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.stpl.eventmanagement.core.bean.Event;
import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.core.dao.IEventDAO;
import com.stpl.eventmanagement.persistence.EntityManager;

public class EventManager extends EntityManager<Event, IEventDAO> implements IEventManager {
	@Autowired
	protected IPlaceManager placeManager;

	public void save(Event record) {
		Boolean flag = validateEvent(record);

		if (flag != false) {
			dao.save(record);
		}

	}

	public int getPlaceIdByEventid(int eventId) {

		int eventPlaceId = 0;
		List<Event> events = dao.getAll();

		for (Event e : events) {
			if (e.getId().equals(eventId)) {
				eventPlaceId = e.getPlaces().getId();
				break;
			}

		}
		return eventPlaceId;
	}

	@Override
	public Boolean validateEvent(Event event) {
		Boolean flag = true;

		String eventName = event.getName();

		String cityOfEvent = event.getCity();

		Place place = placeManager.getPlaceByCity(cityOfEvent);

		if (place.getCity() == null) {
			Place places = new Place();
			places.setCity(cityOfEvent);
			placeManager.save(places);
			event.setPlaces(places);
		} else {
			event.setPlaces(place);
		}
		List<Event> eventList = getAll();

		if (eventList.size() >= 1) {
			for (int i = 0; i < eventList.size(); i++) {
				String DBEvent = eventList.get(i).getName();
				String DBEventCity = eventList.get(i).getPlaces().getCity();

				if ((eventName.toLowerCase().equals(DBEvent.toLowerCase()))
						&& (cityOfEvent.toLowerCase().equals(DBEventCity.toLowerCase()))) {
					System.out.println(DBEvent + " event is already available.");
					assertEquals("Event Name not matching", eventName, DBEvent);

					flag = false;
				}
			}
			if (flag == true) {
				System.out.println("Event Saved Successfully.");

			}

		} else {
			System.out.println("new Event");
			// eventManager.save(event);
			flag = true;
		}

		return flag;
	}

	/* Get Events by place */
	public List<Event> getEventByPlace(int PlaceId) {
		List<Event> eventList = new ArrayList<Event>();
		List<Event> events = getAll();
		System.out.println(events.size());
		if (events.size() == 0) {
			// eventList = null;
			System.out.println("----==== List is Empty =====----");
		} else {
			System.out.println("---------------------");
			System.out.println("ID : Name ");
			System.out.println("---------------------");
			for (Event e : events) {
				if (e.getPlaces().getId() == PlaceId) {
					eventList.add(e);
					System.out.println(e.getId() + " : " + e.getName());
				}
			}
		}

		return eventList;
	}

	public Event updateEvent(int eventId, String eventName) {

		System.out.println("------------------------");
		System.out.println("      Update Mode");
		System.out.println("------------------------");

		List<Event> eventList = getAll();

		Event eventObj = getById(eventId);

		int inFlag = 0;
		Boolean failMsg = false;

		for (Event event : eventList) {
			if (event.getId() == eventId) {

				if ((event.getName().equals(eventName))) {
					System.out.println("Event is already updated.");
					inFlag=0;
					failMsg = false;
					break;
				} else {
					inFlag = 1;
					failMsg = false;
					break;
				}
			} else {
				failMsg = true;
			}
		}
		if (inFlag == 1) {
			eventObj.setName(eventName);
			dao.save(eventObj);
			System.out.println("Event Updated ");
		}
		if (failMsg == true) {
			System.out.println("Event ID not Found.");
		}
		return eventObj;

	}
	
	
	public int getEventIdByName(String eventName) {
		int eventId = 0;
		List<Event> eventList = getAll();
		for(Event event : eventList) {
			if(event.getName().equals(eventName)) {
				eventId = event.getId();
				break;
			}
		}
		return eventId;
	}

}
