package com.stpl.eventmanagement.persistence;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;


@Transactional
public abstract class EntityManager<IEntityType, IEntityDAOType extends IEntityDAO<IEntityType>> implements IEntityManager<IEntityType> {
   
    private static final Logger logger = Logger.getLogger(EntityManager.class);
    protected IEntityDAO<IEntityType> dao;

    public IEntityDAO getEntityDAO() {
        return dao;
    }

    public void setEntityDAO(IEntityDAO dao) {
        this.dao = dao;
    }

    @Override
    @Transactional(readOnly = false)
    public void save(IEntityType record) {
        if (logger.isTraceEnabled()) {
            logger.trace("EntityManager save(IEntityType) - start");
        }
        logger.info("EntityManager save(IEntityType) - start");
        getEntityDAO().save(record);
      
        if (logger.isTraceEnabled()) {
            logger.trace("EntityManager save(IEntityType) - end");
        }
    }

	@Override
    public IEntityType getById(Integer id) {
        if (logger.isTraceEnabled()) {
            logger.trace("getById(ObjectId) - start");
        }

        IEntityType returnIEntityType = (IEntityType) getEntityDAO().getById(id);

        if (logger.isTraceEnabled()) {
            logger.trace("getById(ObjectId) - end");
        }
        return returnIEntityType;
    }
    
    
    public List<IEntityType> getAll() {
        if (logger.isTraceEnabled()) {
            logger.trace("getAll() - start");
        }
        List<IEntityType> returnList = getEntityDAO().getAll();
        if (logger.isTraceEnabled()) {
            logger.trace("getAll() - end");
        }
        return returnList;
    }

    @Override
    @Transactional(readOnly = false)
    public void delete(IEntityType record) {
        if (logger.isTraceEnabled()) {
            logger.trace("delete(IEntityType) - start");
        }

        getEntityDAO().delete(record);
        if (logger.isTraceEnabled()) {
            logger.trace("delete(IEntityType) - end");
        }
    }
	/*
	 * @Override public Boolean checker(List<User> userList,String oldUser) {
	 * Boolean flag ; if(logger.isTraceEnabled()) {
	 * logger.trace("Available(IEntityType) - Start"); } flag =
	 * getEntityDAO().checker(userList,oldUser); return flag;
	 * 
	 * }
	 */

}
