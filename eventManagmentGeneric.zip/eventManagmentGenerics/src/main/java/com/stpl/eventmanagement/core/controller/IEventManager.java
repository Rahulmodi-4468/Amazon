package com.stpl.eventmanagement.core.controller;

import java.util.List;

import com.stpl.eventmanagement.core.bean.Event;

import com.stpl.eventmanagement.persistence.IEntityManager;

public interface IEventManager extends IEntityManager<Event>{
	public Boolean validateEvent(Event event);
	
	public void save(Event record);
	
	public int getPlaceIdByEventid(int eventId);
	
	public List<Event> getEventByPlace(int PlaceId);
	
	public Event updateEvent(int eventId,String eventName);
	
	public int getEventIdByName(String eventName) ;
}
