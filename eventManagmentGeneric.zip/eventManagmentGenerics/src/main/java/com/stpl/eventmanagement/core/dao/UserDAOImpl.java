package com.stpl.eventmanagement.core.dao;

import java.util.List;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.persistence.EntityDAOImpl;

public class UserDAOImpl extends EntityDAOImpl<User> implements IUserDAO {

	@Override
	public Class<User> getTargetClass() {
		return User.class;
	}

	public List<User> getUsersByDOB(String year) {
		Session currentSession = getHibernateTemplate().getSessionFactory().getCurrentSession();
		String sql = "SELECT * FROM eventdb.user WHERE DOB LIKE '" + year + "%'";
		SQLQuery query = currentSession.createSQLQuery(sql);
		query.addEntity(User.class);

		@SuppressWarnings("unchecked")
		List<User> results = query.list();
		return results;
	}

	/*
	 * This class will fetch the employees for particular name specified by the user
	 */
	public List<User> getUsersByName(String name) {
		Session currentSession = getHibernateTemplate().getSessionFactory().getCurrentSession();
		String sql = "SELECT * FROM eventdb.user WHERE name = " + name;
		SQLQuery query = currentSession.createSQLQuery(sql);
		query.addEntity(User.class);

		@SuppressWarnings("unchecked")
		List<User> results = query.list();
		return results;
	}

	public void subscribeEventByUser(int userId, int eventId) {
		Session currentSession = getHibernateTemplate().getSessionFactory().getCurrentSession();
		String sql = "insert into eventdb.UserEvents(user_id,event_id) select u.id,e.id from eventdb.user u inner join eventdb.event e on u.place_id = e.place_id where u.id ="
				+ userId + " && e.id =" + eventId;
		SQLQuery query = currentSession.createSQLQuery(sql);
		query.executeUpdate();
		System.out.println("insertion done");

	}

	public void save(User record) {
		System.out.println("Saved");
		super.save(record);
	}

//	public Boolean checker(List<User> userList,String oldUser) {
//		System.out.println("In checker");
//		Boolean flag = true;
//		if (userList.size() >= 1) {
//			System.out.println(userList.size() + "in >1 loop");
//			for (int i = 0; i < userList.size(); i++) {
//				String DBUser = userList.get(i).getName();
//				
//				System.out.println(DBUser);
//				if (oldUser.equals(DBUser)) {
//					System.out.println(DBUser + "is equal");
//					//assertEquals("USer Name not matching", oldUser, DBUser);
//					flag = false;
//				}
//			}
//			if (flag == true) {
//				System.out.println(" is not equal");
//				flag = true;
//				//userManager.save(user);
//			}
//
//		} 
//		else {
//			System.out.println("new user");
//			//userManager.save(user);
//			flag = true;
//		}
//		return flag;
//	}

}
