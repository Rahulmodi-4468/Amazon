package com.stpl.eventmanagement.core.controller;


import java.util.List;

import com.stpl.eventmanagement.core.bean.User_Events;
import com.stpl.eventmanagement.persistence.IEntityManager;

public interface IUserEventManager extends IEntityManager<User_Events>{
	public void save(User_Events record);
	public boolean validateUsersEvent(int userId , int eventId);
	
	public List<Integer> getUsersByEventId(int eventId);
 }
