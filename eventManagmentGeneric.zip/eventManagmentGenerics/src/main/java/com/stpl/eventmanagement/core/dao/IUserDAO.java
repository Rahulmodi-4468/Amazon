package com.stpl.eventmanagement.core.dao;

import java.util.List;

import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.persistence.IEntityDAO;

public interface IUserDAO extends IEntityDAO<User>{

	public List<User> getUsersByDOB(String year);
	public List<User> getUsersByName(String name);
	public void subscribeEventByUser(int userId,int eventId);
	public void save(User record);
}
