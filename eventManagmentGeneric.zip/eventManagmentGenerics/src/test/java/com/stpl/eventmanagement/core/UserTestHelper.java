package com.stpl.eventmanagement.core;

import org.junit.Ignore;

import com.stpl.eventmanagement.core.bean.Event;
import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.core.bean.User_Events;

@Ignore
public class UserTestHelper {

	static Event event = new Event();
	static User user = new User();
	static Place place = new Place();
	static User_Events userEvent = new User_Events();

	public static User getNewUser() {
		user.setName("test user");
		user.setDOB("1995-06-15");
		user.setCity("Ahmedabad");
		return user;
	}

	public static Event getNewEvent() {

		event.setName("Balloon");
		event.setCity("Manali");
		return event;
	}

	public static Place getNewPlace() {
		place.setCity("Kathmandu");
		return place;
	}

	public static User_Events getNewUserEvents() {
		int user_id = 8;
		int event_id = 13;

		userEvent.setUser_id(user_id);
		userEvent.setEvent_id(event_id);

		return userEvent;
	}
}
