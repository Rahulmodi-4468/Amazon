package com.stpl.eventmanagement.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.test.context.transaction.TransactionConfiguration;
//import java.util.logging.Logger;
import com.stpl.eventmanagement.core.bean.Event;
import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.core.bean.User_Events;

@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class TestUserManagement extends BaseManagerTest {

	private static final Logger logger = Logger.getLogger(TestUserManagement.class);
	//private static final Logger logger = Logger.getLogger(TestUserManagement.class);
	
	// add atleast 3 test cases  
	/*
	 * 
	 * User
	 * 
	 **/

	/* FOR SAVING RECORD IN DATABASE */
	@Test
	@Ignore
	public void saveUserDetailTest() {
		logger.info("-----saveUserTest----- :: Start --------");

		User user = UserTestHelper.getNewUser();

		userManager.save(user);

		assertNotNull("User object has not been saved correctly.", user.getId());
		logger.info("-----saveUserTest----- :: End --------");
	}

	/* FOR DELETING DATABASE RECORDS */
	@Test
	@Ignore
	public void deleteUserTest() {
		logger.info("-----deleteUserTest----- :: Start --------");
		System.out.println("--- Deletion Mode ---");

		int userId = 19;
		User savedUser = userManager.getById(userId);

		userManager.delete(savedUser);

		assertNull("User object has not been deleted correctly.", userManager.getById(userId));
		logger.info("-----deleteUserTest----- :: End --------");
	}

	/* FOR UPDATING PARTICULAR RECORDS */
	@Test
	@Ignore
	public void updateUserTest() {
		logger.info("-----updateUsertTest----- :: Start --------");
		System.out.println("---- Update Mode ----");

		int userId = 15;
		String userName = "test user";
		
		User savedUser = userManager.getById(userId);
		savedUser.setName(userName);

		userManager.save(savedUser);

		User updatedUser = userManager.getById(userId);

		assertEquals("User Not Updated", userName, updatedUser.getName());
		System.out.println("User saved " + savedUser.getName() + " to " + userName);

		logger.info("-----updateUserTest----- :: End --------");
	}

	/* RETRIVING PARTICULAR RECORD FROM DATABASE */
	@Test
	@Ignore
	public void retriveUserTest() {
		logger.info("-----retriveUserTest----- :: Start --------");
		int userId = 1;
		User savedUser = userManager.getById(userId);
		System.out.println(savedUser.getName() + " : " + savedUser.getDOB());
		assertNotNull("User object has not been saved correctly.", savedUser);
		logger.info("-----retriveUserTest----- :: End --------");
	}

	/* RUNNING TEST CASE FOR GETTING STUDENT OF SPECIFIED YEAR */
	@Test
	@Ignore
	public void getUserbyDOB() {
		logger.info("-----User_DOB_Test----- :: Start --------");
		String year = "1999";

		userManager.getUsersByDOB(year);

		logger.info("-----User_DOB_Test----- :: End --------");
	}

	@Test
	@Ignore
	public void getAllUsers() {
		logger.info("-----User_getAllUser_Test----- :: Start --------");

		List<User> users = userManager.getAll();

		System.out.println("-----------------------");
		System.out.println("ID : Name  :  DOB");
		System.out.println("-----------------------");

		for (User u : users) {
			System.out.println(u.getId() + " : " + u.getName() + " : " + u.getDOB());

		}

		System.out.println("-----------------------");

		logger.info("-----User_getAllUser_Test----- :: End --------");
	}

	/*
	 * 
	 * Event
	 * 
	 **/
	@Test
	@Ignore
	public void saveEventTest() {
		logger.info("-----saveEventTest----- :: Start --------");

		Event event = UserTestHelper.getNewEvent();

		eventManager.save(event);

		assertNotNull("Event object has not been saved correctly.", event.getId());

		logger.info("-----saveEventTest----- :: End --------");
	}

	/* FOR DELETING DATABASE RECORDS */
	@Test
	@Ignore
	public void deleteEventTest() {
		logger.info("-----deleteEventTest----- :: Start --------");

		System.out.println("--- Deletion Mode ---");
		int eventId = 22;

		Event savedEvent = eventManager.getById(eventId);

		eventManager.delete(savedEvent);

		System.out.println(savedEvent.getName() + " Event Deleted.");
		assertNull("Event object has not been deleted correctly.", eventManager.getById(eventId));

		logger.info("-----deleteEventTest----- :: End --------");
	}

	/* FOR UPDATING PARTICULAR RECORDS */
	@Test
	@Ignore
	public void updateEventTest() {

		logger.info("-----updateEventtTest----- :: Start --------");

		int eventId = 25;
		String eventName = "donation";

		eventManager.updateEvent(eventId, eventName);

		Event updatedEvent = eventManager.getById(eventId);

		assertEquals("Event is not update properly", eventName, updatedEvent.getName());

		logger.info("-----updateEventTest----- :: End --------");
	}

	/*
	 * 
	 * Place
	 * 
	 **/

	@Test
	@Ignore
	public void savePlaceTest() {
		logger.info("-----savePlaceTest----- :: Start --------");

		Place place = UserTestHelper.getNewPlace();

		placeManager.save(place);

		assertNull("Place object has not been saved correctly.", place.getId());

		logger.info("-----savePlaceTest----- :: End --------");
	}

	/* FOR DELETING DATABASE RECORDS */

	@Test
	@Ignore
	public void deletePlaceTest() {
		logger.info("-----deletePlaceTest----- :: Start --------");

		int placeId = 19;
		Place place = placeManager.getById(placeId);

		if (place.getCity() != null) {
			placeManager.delete(place);
			System.out.println(place.getCity() + " Place Deleted.");
		} else {
			System.out.println("Not deleted");
		}

		assertNotNull("Place object has not been deleted correctly.", place.getId());

		logger.info("-----deletePlaceTest----- :: End --------");
	}

	@Test
	@Ignore
	public void updatePlaceTest() {

		logger.info("-----updatePlacetTest----- :: Start --------");

		int placeId = 15;
		String cityOfPlace = "Leh";

		placeManager.updatePlace(placeId, cityOfPlace);
		
		Place updatedPlace = placeManager.getById(placeId);

		String updatePlaceName = updatedPlace.getCity();
		assertEquals(cityOfPlace, updatePlaceName);
		logger.info("-----updatePlaceTest----- :: End --------");
	}

	@Test
	@Ignore
	public void subscribeEventTest() {

		logger.info("-----SubscribeUserEventTest----- :: Start --------");

		User_Events userEvent = UserTestHelper.getNewUserEvents();
		System.out.println(" In subscribe USer event ==>  Event ID : " + userEvent.getEvent_id());
		userEventManager.save(userEvent);

		assertNotNull("user object has not been saved correctly.", userEvent.getUser_id());
		assertNotNull("Event object has not been saved correctly.", userEvent.getEvent_id());
		logger.info("-----SubscribeUserEventTest----- :: End --------");

	}



	@Test
	@Ignore
	public void getUsersByEvent() {

		logger.info("-----getUsersByEvent----- :: Start --------");
		
		String eventName = "Social Distancing";
		
		userManager.getUsersByEvent(eventName);
		
		logger.info("-----getUsersByEvent----- :: End --------");

	}
}
