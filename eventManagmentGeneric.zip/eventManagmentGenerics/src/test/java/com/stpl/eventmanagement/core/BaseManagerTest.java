package com.stpl.eventmanagement.core;

import org.junit.Ignore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import com.stpl.eventmanagement.core.controller.IEventManager;
import com.stpl.eventmanagement.core.controller.IPlaceManager;
import com.stpl.eventmanagement.core.controller.IUserEventManager;
import com.stpl.eventmanagement.core.controller.IUserManager;



@ContextConfiguration({ "/testApplicationContext.xml" })
@Ignore
public abstract class BaseManagerTest extends AbstractTransactionalJUnit4SpringContextTests {

	@Autowired
	protected IUserManager userManager;
	
	@Autowired
	protected IEventManager eventManager;
	
	@Autowired
	protected IPlaceManager placeManager;
	
	
	 @Autowired 
	 protected IUserEventManager userEventManager;
	 
	/*
    @Before
    public void onSetUp() throws Exception {
        UserHelper.setCurrentUser("Junit"); 
        
    }

    protected void flushSession() {
        brightCloudSessionFactory.getCurrentSession().flush();
    }*/
	
}
