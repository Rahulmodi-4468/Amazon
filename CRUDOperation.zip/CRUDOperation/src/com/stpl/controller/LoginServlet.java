package com.stpl.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.PropertyConfigurator;

import org.apache.log4j.Logger;
import org.apache.log4j.BasicConfigurator;
import java.util.*;
import java.io.*;

import com.stpl.bean.RegistrationBean;
import com.stpl.dao.FoodStoreDAO;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(LoginServlet.class);
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//FileHandler handler = new FileHandler("/home/st6/Projects/software-trainee/workspace/CRUDOperation/Files/logs.txt");
		//logger.addHandler(handler);
		
		BasicConfigurator.configure();
		
		String path = "/home/st6/Projects/software-trainee/server/apache-tomcat-9.0.56/webapps/CRUDOperation/WEB-INF/classes/log4j.properties";
        PropertyConfigurator.configure(path);
        
        
		PrintWriter out = response.getWriter();
		String uname = request.getParameter("uname");
		String password = request.getParameter("pwd");

		RegistrationBean bean = new RegistrationBean();
		bean.setUname(uname);
		bean.setPassword(password);

		int status = 0;
		try {
			status = FoodStoreDAO.authenticateUser(bean); // loginDAO.loginInsert(bean);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (status > 0) {
			
			logger.info(uname +" Logged In.");
			
			HttpSession session = request.getSession();
			session.setAttribute("username", uname);
			System.out.print("Authenticate User!");
			request.getRequestDispatcher("crudoperation.jsp").include(request, response);

		} else {
			String errorMsg = "username or password wrong";
			request.setAttribute("errMessage", errorMsg);
			request.getRequestDispatcher("login.jsp").include(request, response);

		}

		out.close();
	}

}
