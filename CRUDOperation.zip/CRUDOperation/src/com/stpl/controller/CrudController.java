package com.stpl.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.stpl.bean.CrudBean;
import com.stpl.dao.FoodStoreDAO;


@WebServlet("/")
public class CrudController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getServletPath();
		System.out.println(action);
		try {
			switch (action) {
			case "/insert":
				insertDetail(request, response);
				break;
			case "/Delete":
				deleteItem(request, response);
				break;
			case "/Update":
				updateItem(request, response);
				break;
			case "/Edit":
				fillDetail(request, response);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	private void insertDetail(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String productName = request.getParameter("name");
		int productPrice = Integer.parseInt(request.getParameter("price"));

		CrudBean bean = new CrudBean();
		bean.setName(productName);
		bean.setPrice(productPrice);

		try {
			FoodStoreDAO.crudInsert(bean);
			System.out.println("return to servlet page");

		} catch (SQLException e) {
			e.printStackTrace();
		}
		response.sendRedirect("crudoperation.jsp");

	}

	private void deleteItem(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		int id = Integer.parseInt(request.getParameter("id"));
		FoodStoreDAO.deleteItem(id);

		response.sendRedirect("crudoperation.jsp");
	}

	private void updateItem(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		int price = Integer.parseInt(request.getParameter("price"));

		CrudBean newDetails = new CrudBean(id, name, price);
		FoodStoreDAO.updateItem(newDetails);
		response.sendRedirect("crudoperation.jsp");
	}

	private void fillDetail(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {

		String id = request.getParameter("id");
		List<String> item = new ArrayList<String>();
		item = FoodStoreDAO.fillDetailById(id);
		request.setAttribute("itemId", item.get(0));
		request.setAttribute("itemname", item.get(1));
		request.setAttribute("itemPrice", item.get(2));
		request.getRequestDispatcher("update.jsp").forward(request, response);
	}

}
