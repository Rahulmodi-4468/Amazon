package com.stpl.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.stpl.bean.RegistrationBean;
import com.stpl.bean.CrudBean;

public class FoodStoreDAO {

	public static Connection getConnection() {

		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Class loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crudoperation", "root", "root");
			System.out.println("connectioned");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return con;

	}

	public static int authenticateUser(RegistrationBean lb) throws SQLException {
		String uname = lb.getUname();
		String password = lb.getPassword();
		int status = 0;

		Connection con = null;
		try {
			con = getConnection();
			System.out.println("Connection Established");
			if (con != null) {
				String selectQuery = "select * from login";
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery(selectQuery);
				while (rs.next()) {
					String nameDB = rs.getString("name");
					String passwordDB = rs.getString("password");
					System.out.println(nameDB + " " + passwordDB);
					if ((uname.equals(nameDB)) && (password.equals(passwordDB))) {
						status = 1;
						System.out.println("uname & password matched");
						break;
					} else {
						System.out.println("wrong");
						status = 0;
					}
				}
				st.close();
			} else {
				System.out.println("Connection issue");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}

	public static int RegistrationDetailInsertion(RegistrationBean rb) throws SQLException {
		String fullName = rb.getFullname();
		String email = rb.getEmail();
		String phone = rb.getPhone();
		String uname = rb.getUname();
		String password = rb.getPassword();
		int status = 0;
		// System.out.println(fullName +" of Registration");
		Connection conn = null;
		try {
			conn = getConnection();
			System.out.println("Connection Established");
			try {
				String insertQuery = "insert into registration(fullname,email,phone,username,password) values(?,?,?,?,?);";
				PreparedStatement ps = conn.prepareStatement(insertQuery);
				ps.setString(1, fullName);
				ps.setString(2, email);
				ps.setInt(3, Integer.parseInt(phone));
				ps.setString(4, uname);
				ps.setString(5, password);
				ps.executeUpdate();

				status = 1;
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

		return status;

	}

	public static void crudInsert(CrudBean cb) throws SQLException {
		String name = cb.getName();
		int price = cb.getPrice();
		// int status = 0;
		System.out.println(name + " " + price);
		Connection conn = null;
		try {
			conn = getConnection();
			System.out.println("Connection Established");
			try {
				String insertQuery = "insert into foodDetails(name,price) values(?,?);";
				PreparedStatement ps = conn.prepareStatement(insertQuery);
				ps.setString(1, name);
				ps.setInt(2, price);

				ps.executeUpdate();

				// status = 1;
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

		// return status;
	}

	public static List<CrudBean> selectAllDetails() {
		Connection conn = null;
		List<CrudBean> item = new ArrayList<>();
		try {
			conn = getConnection();
			System.out.println("Connection Established");
			try {
				String getQuery = "select * from foodDetails";
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(getQuery);
				while (rs.next()) {

					int id = rs.getInt("id");
					String name = rs.getString("name");
					int price = rs.getInt("price");

					item.add(new CrudBean(id, name, price));

					System.out.println(id + " " + name + " " + price);
				}
				st.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
		return item;
	}

	public static void deleteItem(int proId) {
		String delQuery = "DELETE FROM foodDetails WHERE id = ?;";

		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(delQuery)) {
			preparedStatement.setInt(1, proId);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public static void updateItem(CrudBean cb) {
		String delQuery = "UPDATE foodDetails SET name = ?, price=? WHERE id = ?; ";

		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(delQuery)) {
			preparedStatement.setString(1, cb.getName());
			preparedStatement.setInt(2, cb.getPrice());
			preparedStatement.setInt(3, cb.getId());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public static List<String> fillDetailById(String id) {
		Connection conn = null;
		List<String> item = new ArrayList<String>();
		try {
			conn = getConnection();
			System.out.println("Connection Established");
			try {
				int updateId = Integer.parseInt(id);
				String getQuery = "select * from foodDetails";
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(getQuery);
				while (rs.next()) {

					int ids = rs.getInt("id");
					if (ids == updateId) {
						String name = rs.getString("name");
						int price = rs.getInt("price");
						item.add(id);
						item.add(name);
						item.add(String.valueOf(price));
						System.out.println(ids + " " + name + " " + price);
					}

				}
				st.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
		return item;
	}

}
