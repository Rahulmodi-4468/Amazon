package com.stpl.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class RegistrationValidation
 */
@WebFilter("/RegistrationController")
public class RegistrationFilter implements Filter {

	public void destroy() {
		// TODO Auto-generated method stub
	}

	static boolean validEmail(String email) {
		return email.matches("[A-Z0-9._%+-][A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{3}");
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest) request;
		String fullName = request.getParameter("fullname");
		String email = request.getParameter("email");
		String ContactNumber = request.getParameter("phone");
		String uname = request.getParameter("uname");
		String password = request.getParameter("password");
		// System.out.println(fullName +" "+password.length());

		if (fullName == null || fullName.isEmpty() || fullName == "") {
			String errorMsg = "Enter Name";
			request.setAttribute("errorMsg", errorMsg);
			request.getRequestDispatcher("Registration.jsp").forward(request, response);
			

		} else {
			System.out.println("IS Valid password");

			System.out.println("Pre filter,it's check validation of data.");
			chain.doFilter(request, response);

			System.out.println("post filter,it can set session.");
			
			HttpSession session = req.getSession();
			session.setAttribute("username", uname);
		}
		/*
		 * if(password.length() >= 6 || password.length() <= 8) {
		 * System.out.println("IS Valid password"); } else { String errorMsg =
		 * "password must be >=6 & <= 8 "; request.setAttribute("errorMsgPWD",
		 * errorMsg); request.getRequestDispatcher("Registration.jsp").forward(request,
		 * response);
		 * 
		 * }
		 * 
		 * 
		 * if(validEmail(email)) { System.out.println("IS Valid Email"); } else { String
		 * errorMsg = "Enter Valid Email"; request.setAttribute("errorMsg", errorMsg);
		 * request.getRequestDispatcher("Registration.jsp").forward(request, response);
		 * 
		 * }
		 */

		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
