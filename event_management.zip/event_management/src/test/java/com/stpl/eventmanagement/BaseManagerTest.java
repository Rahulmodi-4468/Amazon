package com.stpl.eventmanagement;

import org.junit.Ignore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;



@ContextConfiguration({ "/testApplicationContext.xml" })
@Ignore
public abstract class BaseManagerTest extends AbstractTransactionalJUnit4SpringContextTests {

	@Autowired(required = true)
	protected IEventManager eventManager;
	
	@Autowired(required = true)
	protected IUserManager userManager;
	
	
	@Autowired(required = true)
	protected IPlaceManager placeManager;
	/*
    @Before
    public void onSetUp() throws Exception {
        UserHelper.setCurrentUser("Junit"); 
        
    }
    

    protected void flushSession() {
        brightCloudSessionFactory.getCurrentSession().flush();
    }*/
	
}
