package com.stpl.eventmanagement;

import static org.junit.Assert.*;
import org.junit.Ignore;
import org.apache.log4j.Logger;
import org.junit.Test;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.stpl.eventmanagement.bean.Event;
import com.stpl.eventmanagement.bean.Place;
import com.stpl.eventmanagement.bean.User;

@TransactionConfiguration(transactionManager="transactionManager", defaultRollback=false)
public class TestEventManagement extends BaseManagerTest{

	private static final Logger logger = Logger.getLogger(TestEventManagement.class);

	/*
	 * 
	 * ----- Event ----- 
	 * 
	 */
	
	/* Save records in database for Event */
	@Test
	@Ignore
	public void savedEventTest() {
		logger.info("-----saveEventTest----- :: Start --------");
		Event e = EventTestHelper.getNewEvent();
		eventManager.save(e);
		assertNotNull("Event object has not been saved correctly.", e.getId());
		logger.info("-----saveEventTest----- :: End --------");   
	
	}
	
    /*FOR UPDATING PARTICULAR RECORDS  */
    @Test
    @Ignore
	public void updateEventTest() {
		
		logger.info("-----updateEventTest----- :: Start --------");
		int eId = 3;
		String eventName = "Gujarat ECS";
		Event savedEvent = eventManager.getById(eId);
		assertNotNull("Event object has not been saved correctly.", savedEvent);
		System.out.println("savedStudent" + savedEvent.getName());

		savedEvent.setName(eventName);
		eventManager.save(savedEvent);

		Event updatedEvent = eventManager.getById(eId);

		String updateEventName = updatedEvent.getName();
		assertEquals(eventName, updateEventName);
		assertNotNull("Student object has not been updated correctly.", savedEvent);

		logger.info("-----updateEventTest----- :: End --------");
	}
    
	/* Delete perticular record from Event */
	@Test
	//@Ignore
	public void deleteEventTest() {
		logger.info("---deleteEventTest--- :: Start ------");
		
		int eventId = 4;
		Event e = eventManager.getById(eventId);
		eventManager.delete(e);
		assertNull("Event object has been deleted correctly.",eventManager.getById(eventId));
		
		logger.info("---deleteEventTest--- :: End  -----");
	}
	
	/* Retrive record from db by id from Event */
	@Test
	@Ignore
	public void retriveEventTest() {
		logger.info("--- retriveEventTest --- :: Start -----");
		int eventId = 6;
		Event e = eventManager.getById(eventId);
		System.out.println("name of event "+ e.getName());
		assertNotNull("Event Object has not been updated",e);
		logger.info(" --- retriveEventTest --- :: End -----");
	}
	
	
	
	/*
	 * 
	 * ----- User ----- 
	 * 
	 */
	
	/* Insert data in db for User*/
	@Test
	@Ignore
	public void savedUserTest() {
		logger.info("-----saveUserTest----- :: Start --------"); 
		User u = EventTestHelper.getNewUser();
		userManager.save(u);
		assertNotNull("User object has not been saved correctly.",u.getId());
		
		//User savedUser = userManager.getById(u.getId());
		//logger.info("-----User data Inserted------");
		logger.info("-----saveUserTest----- :: End --------");   
	}
	
	/* Delete perticular record from User */
	@Test
	@Ignore
	public void deleteUserTest() {
		logger.info("---deleteEventTest--- :: Start ------");
		
		int userId = 1;
		User u =userManager.getById(userId);
		userManager.delete(u);
		assertNull("Event object has been deleted correctly.",eventManager.getById(userId));
		
		logger.info("---deleteEventTest--- :: End  -----");
	}
	
	/* Retrive record from db by id from User */
	@Test
	@Ignore
	public void retriveUserTest() {
		logger.info("--- retriveUserTest --- :: Start -----");
		int userId = 6;
		User u = userManager.getById(userId);
		System.out.println("name of event "+ u.getName());
		assertNotNull("User Object has not been updated",u);
		logger.info(" --- retriveUserTest --- :: End -----");
	}
	
	
	

	/*
	 * 
	 * ----- Place ----- 
	 * 
	 */
	
	/* Save records in database for Event */
	@Test
	@Ignore
	public void savedPlaceTest() {
		logger.info("-----saveEventTest----- :: Start --------");
		Place p = EventTestHelper.getNewPlace();
		
		placeManager.save(p);
		assertNotNull("Event object has not been saved correctly.", p.getId());
		
	    //Place savedPlace = placeManager.getById(p.getId());
        //assertEquals("Both User ids are not equals", p.getId(), savedPlace.getId());

		logger.info("-----saveEventTest----- :: End --------");   
	
	}
	

}
