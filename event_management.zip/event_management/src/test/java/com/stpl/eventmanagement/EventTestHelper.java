package com.stpl.eventmanagement;

import org.junit.Ignore;
import com.stpl.eventmanagement.bean.Event;
import com.stpl.eventmanagement.bean.Place;
import com.stpl.eventmanagement.bean.User;
@Ignore
public class EventTestHelper {
	
	static Event event = new Event();
	static User user = new User();
	static Place place = new Place();
	
	public static void setAllData() {
		event.setName("Vibrant Gujarat");
		
		user.setName("Rahul");
		
		place.setId(2);
		place.setCity("Baroda");
		place.getEvent().add(event);
		place.getUser().add(user);
		
		event.setPlaces(place);
		user.setPlace(place);
	}
	public static Event getNewEvent()
	{
		setAllData();
		return event;
	}
	
	public static User getNewUser() {
		setAllData();
		return user;
	}
	
	public static Place getNewPlace() {
		setAllData();
		return place;
	}

}
