package com.stpl.eventmanagement.exception;

public class StudentManagementException extends RuntimeException {

    private static final long serialVersionUID = -3410113524956843103L;

    public StudentManagementException(String message) {
        super(message);
    }

    public StudentManagementException(Throwable t) {
    	super(t);
    }

	public StudentManagementException(String msg, Throwable cause) {
		super(msg, cause);
	}
}
