package com.stpl.eventmanagement.dao;

import com.stpl.eventmanagement.bean.Place;

public interface IPlaceDAO {
	public void save(Place record);
	public void delete(Place record);
	public Place getById(Integer id);
}
