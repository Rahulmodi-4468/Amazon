package com.stpl.eventmanagement;

import org.springframework.transaction.annotation.Transactional;

import com.stpl.eventmanagement.bean.User;
import com.stpl.eventmanagement.dao.IUserDAO;

public class UserManager implements IUserManager {

	protected IUserDAO dao;
	
	
	public IUserDAO getUserDao() {
		return dao;
	}


	public void setUserDao(IUserDAO dao) {
		this.dao = dao;
	}


	public void save(User record) {
		getUserDao().save(record);
	}

	//@Override
	@Transactional(readOnly=false)
	public void delete(User record) {
		getUserDao().delete(record);
	}


	public User getById(int eventId) {
		User e = (User) getUserDao().getById(eventId);
		return e;
	}
}
