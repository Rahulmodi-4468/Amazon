package com.stpl.eventmanagement;

import java.util.ArrayList;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.stpl.eventmanagement.bean.Event;
import com.stpl.eventmanagement.dao.IEventDAO;

public class EventManager implements IEventManager {

	protected IEventDAO dao;
	
	
	public IEventDAO getDao() {
		return dao;
	}


	public void setDao(IEventDAO dao) {
		this.dao = dao;
	}


	public void save(Event record) {
		getDao().save(record);
	}

	//@Override
	@Transactional(readOnly=false)
	public void delete(Event record) {
		getDao().delete(record);
	}


	public Event getById(int eventId) {
		Event e = (Event) getDao().getById(eventId);
		return e;
	}


//	public List<Event> geteventsByCityName(String city) {
//		List<Event> e = getEventDao().geteventsByCityName(city);
//		
//		return e;
//	}
}
