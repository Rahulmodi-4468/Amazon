package com.stpl.eventmanagement;

import java.util.List;

import com.stpl.eventmanagement.bean.Event;
import com.stpl.eventmanagement.bean.Place;
import com.stpl.eventmanagement.bean.User;

public interface IEventManager {

	public void save(Event e);
	public void delete(Event record);
	public Event getById(int eventId);
//	public List<Event> geteventsByCityName(String city); 
//	
}
