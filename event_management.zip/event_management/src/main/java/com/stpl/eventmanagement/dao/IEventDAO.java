package com.stpl.eventmanagement.dao;

import java.util.List;

import com.stpl.eventmanagement.bean.Event;

public interface IEventDAO {

	public void save(Event record);
	public void delete(Event record);
	public Event getById(Integer id);
	public List<Event> geteventsByCityName(String city);
	public List<Event> getAllData();

}
