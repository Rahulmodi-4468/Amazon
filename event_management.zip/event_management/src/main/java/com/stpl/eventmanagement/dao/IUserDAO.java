package com.stpl.eventmanagement.dao;

import com.stpl.eventmanagement.bean.User;

public interface IUserDAO {

	public void save(User record);
	public void delete(User record);
	public User getById(Integer id);
}
