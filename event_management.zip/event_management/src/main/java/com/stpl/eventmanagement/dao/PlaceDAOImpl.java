package com.stpl.eventmanagement.dao;

import org.apache.log4j.Logger;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import com.stpl.eventmanagement.bean.Place;


public class PlaceDAOImpl extends HibernateDaoSupport implements IPlaceDAO{

	private static final Logger logger = Logger.getLogger(UserDAOImpl.class);

	@Transactional(readOnly = false)
	public void save(Place record) {
		if (logger.isTraceEnabled()) {
			logger.trace("save(IEntityType) - start");
		}
		getHibernateTemplate().saveOrUpdate(record);
		if (logger.isTraceEnabled()) {
			logger.trace("save(IEntityType) - end");
		}
		
	}

	public void delete(Place record) {
		if (logger.isTraceEnabled()) {
			logger.trace("Delete(IEntityType) - start");
		}
		getHibernateTemplate().delete(record);
		if (logger.isTraceEnabled()) {
			logger.trace("Delete(IEntityType) - end");
		}
	}

	public Place getById(Integer id) {
		 if (logger.isTraceEnabled()) {
	            logger.trace("getById(ObjectId) - start");
	        }
	       
	        Place e = (Place) getHibernateTemplate().get(Place.class,id);
	        if (logger.isTraceEnabled()) {
	            logger.trace("getById(ObjectId) - end");
	        }
	        return e;
	}
	
}
