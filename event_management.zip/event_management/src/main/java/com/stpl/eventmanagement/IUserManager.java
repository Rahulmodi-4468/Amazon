package com.stpl.eventmanagement;

import com.stpl.eventmanagement.bean.User;

public interface IUserManager {

	public void save(User record);
	public void delete(User record);
	public User getById(int userId);
	
}
