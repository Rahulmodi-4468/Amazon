package com.stpl.eventmanagement;

import com.stpl.eventmanagement.bean.Place;

public interface IPlaceManager {
	public void save(Place record);
	public void delete(Place record);
	public Place getById(int userId);
}
