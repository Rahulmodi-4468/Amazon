package com.stpl.eventmanagement;

import org.springframework.transaction.annotation.Transactional;

import com.stpl.eventmanagement.bean.Place;
import com.stpl.eventmanagement.dao.IPlaceDAO;

public class PlaceManager implements IPlaceManager {
	protected IPlaceDAO dao;
	public void setPlaceDao(IPlaceDAO dao) {
		this.dao = dao;
	}

	public IPlaceDAO getPlaceDao() {
		return dao;
	}

	@Transactional(readOnly = false)
	public void save(Place record) {
		
		getPlaceDao().save(record);
	}

	public Place getById(Integer id) {
		 Place returnIEntityType = (Place) getPlaceDao().getById(id);   
	     return returnIEntityType;
	}
	
	@Transactional(readOnly = false)
	public void delete(Place entity) {
		getPlaceDao().delete(entity);
	}

	public Place getById(int userId) {
		// TODO Auto-generated method stub
		return null;
	}
}


