package com.stpl.eventmanagement.dao;

import org.apache.log4j.Logger;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import com.stpl.eventmanagement.bean.Event;
import com.stpl.eventmanagement.bean.User;

public class UserDAOImpl extends HibernateDaoSupport implements IUserDAO {

	private static final Logger logger = Logger.getLogger(UserDAOImpl.class);

	@Transactional(readOnly = false)
	public void save(User record) {
	
		if (logger.isTraceEnabled()) {
			logger.trace("save(IEntityType) - start");
		}
		getHibernateTemplate().saveOrUpdate(record);
		if (logger.isTraceEnabled()) {
			logger.trace("save(IEntityType) - end");
		}
	}
	
    public User getById(Integer id) {
        if (logger.isTraceEnabled()) {
            logger.trace("getById(ObjectId) - start");
        }
       
        User e = (User) getHibernateTemplate().get(User.class,id);
        if (logger.isTraceEnabled()) {
            logger.trace("getById(ObjectId) - end");
        }
        return e;
    }
    
	public void delete(User record) {
		if (logger.isTraceEnabled()) {
			logger.trace("Delete(IEntityType) - start");
		}
		getHibernateTemplate().delete(record);
		if (logger.isTraceEnabled()) {
			logger.trace("Delete(IEntityType) - end");
		}
	}



}
