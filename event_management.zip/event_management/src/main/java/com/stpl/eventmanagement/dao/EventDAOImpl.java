package com.stpl.eventmanagement.dao;

import java.util.ArrayList;
import java.util.List;


import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.stpl.eventmanagement.bean.Event;

public class EventDAOImpl extends HibernateDaoSupport implements IEventDAO {

	private static final Logger logger = Logger.getLogger(EventDAOImpl.class);

	public void save(Event record) {
	
		if (logger.isTraceEnabled()) {
			logger.trace("save(IEntityType) - start");
		}
		getHibernateTemplate().saveOrUpdate(record);
		if (logger.isTraceEnabled()) {
			logger.trace("save(IEntityType) - end");
		}
	}
	
	
    public Event getById(Integer id) {
        if (logger.isTraceEnabled()) {
            logger.trace("getById(ObjectId) - start");
        }
       
        Event e = (Event) getHibernateTemplate().get(Event.class,id);
        if (logger.isTraceEnabled()) {
            logger.trace("getById(ObjectId) - end");
        }
        return e;
    }
    
	public void delete(Event record) {
		if (logger.isTraceEnabled()) {
			logger.trace("Delete(IEntityType) - start");
		}
		getHibernateTemplate().delete(record);
		if (logger.isTraceEnabled()) {
			logger.trace("Delete(IEntityType) - end");
		}
	}

	public List<Event> geteventsByCityName(String city) {
		List<Event> e = new ArrayList<Event>();
		   if (logger.isTraceEnabled()) {
	            logger.trace("getById(ObjectId) - start");
	        }
	       
	        e = (List<Event>) getHibernateTemplate().get(Event.class,city);
	        if (logger.isTraceEnabled()) {
	            logger.trace("getById(ObjectId) - end");
	        }
	        return e;
	}


	public List<Event> getAllData() {
		
	  return null;
	}

}
