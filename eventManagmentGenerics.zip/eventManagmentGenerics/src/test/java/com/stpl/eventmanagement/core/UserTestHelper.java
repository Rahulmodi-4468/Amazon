package com.stpl.eventmanagement.core;

import java.util.Scanner;

import org.junit.Ignore;

import com.stpl.eventmanagement.core.bean.Event;
import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.core.bean.User;


@Ignore
public class UserTestHelper {

	private static final Scanner sc = new Scanner(System.in);
	static Event event = new Event();
	static User user = new User();
	static Place place = new Place();
	
	public static void setAllData() {
		event.setName("Riverfront");
		
		user.setName("Ramesh");
		user.setDOB("1995-02-05");
		
		//place.setId(5);
		place.setCity("Sanand");
		
//		place.getEvent().add(event);
//		place.getUser().add(user);
		
		event.setPlaces(place);
		user.setPlace(place);
	}

	public static User getNewUser()
	{
		setAllData();
		return user;
	}

	public static Event getNewEvent() {
		
		System.out.println("Enter Event Name : ");
		String eventName = sc.nextLine();
		event.setName(eventName);
		
		String cityOfEvent = sc.nextLine();
		Place place = getNewPlace();
		event.setPlaces(place);
		return event;
	}
	
	public static Place getNewPlace() {
		setAllData();
		return place;
		
//		System.out.println("Enter Place Id : ");
//		int placeId = sc.nextInt();
//		System.out.println("Enter Place City : ");
//		System.out.println("---------------------");
//		String placeCity ;
//		placeCity = sc.nextLine();
//		place.setId(placeId);
//		place.setCity(placeCity);
//		return place;
	}
}
