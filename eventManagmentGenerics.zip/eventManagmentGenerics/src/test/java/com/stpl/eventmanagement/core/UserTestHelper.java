package com.stpl.eventmanagement.core;

import org.junit.Ignore;

import com.stpl.eventmanagement.core.bean.Event;
import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.core.bean.User;


@Ignore
public class UserTestHelper {

	
	static Event event = new Event();
	static User user = new User();
	static Place place = new Place();
	
	public static void setAllData() {
		event.setName("vibrant gujarat");
		
		user.setName("shradha bafna");
		user.setDOB("2000-11-10");
		
		place.setId(3);
		place.setCity("Baroda");
		
		place.getEvent().add(event);
		place.getUser().add(user);
		
		event.setPlaces(place);
		user.setPlace(place);
	}
	public static User getNewUser()
	{
		setAllData();
		return user;
	}

	public static Event getNewEvent() {
		setAllData();
		return event;
	}
	
	public static Place getNewPlace() {
		setAllData();
		return place;
	}
}
