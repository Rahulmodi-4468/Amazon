package com.stpl.eventmanagement.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.stpl.eventmanagement.core.bean.Event;
import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.core.bean.User;

@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class TestUserManagement extends BaseManagerTest {

	private static final Logger logger = Logger.getLogger(TestUserManagement.class);
	private int noice = 0;
	private static final Scanner sc = new Scanner(System.in);

	/*
	 * 
	 * USer
	 * 
	 **/
	/* FOR SAVING RECORD IN DATABASE */
	@Test
	@Ignore
	public void saveUserTest() {
		logger.info("-----saveUserTest----- :: Start --------");

		User user = UserTestHelper.getNewUser();
		String oldUser = user.getName();

		List<User> userList = userManager.getAll();

		Boolean flag = false;

		// checker method check in DB is user is exists or not!
		flag = userManager.checker(userList, oldUser);

		System.out.println("user ==> " + flag);
		if (flag == true) {
			userManager.save(user);
		} else {
			assertFalse("User is already exists!", true);
			System.out.println("User is already exists.");
		}

		logger.info("-----saveUserTest----- :: End --------");
	}

	/* FOR DELETING DATABASE RECORDS */
	@Test
	@Ignore
	public void deleteUserTest() {
		logger.info("-----deleteUserTest----- :: Start --------");

		int userId = 42;
		User savedUser = userManager.getById(userId);
		System.out.println("---" + savedUser.getDOB() + "---" + savedUser.getName());
		userManager.delete(savedUser);
		assertNull("User object has not been deleted correctly.", userManager.getById(userId));

		logger.info("-----deleteUserTest----- :: End --------");
	}

	/* FOR UPDATING PARTICULAR RECORDS */
	@Test
	// @Ignore
	public void updateUserTest() {
		System.out.println("in");
		logger.info("-----updateUsertTest----- :: Start --------");
		int userId = 28;
		String userName = "Subhash";
		User savedUser = userManager.getById(userId);
		assertNotNull("User object has not been saved correctly.", savedUser);
		System.out.println("savedStudent" + savedUser.getDOB());

		savedUser.setName(userName);
		userManager.save(savedUser);

		User updatedUser = userManager.getById(userId);

		String updateUserName = updatedUser.getName();
		assertEquals(userName, updateUserName);
		assertNotNull("User object has not been updated correctly.", savedUser);

		logger.info("-----updateUserTest----- :: End --------");
	}

	/* RETRIVING PARTICULAR RECORD FROM DATABASE */
	@Test
	@Ignore
	public void retriveUserTest() {
		logger.info("-----retriveUserTest----- :: Start --------");
		int userId = 1;
		User savedUser = userManager.getById(userId);
		System.out.println(savedUser.getName());
		assertNotNull("User object has not been saved correctly.", savedUser);
		logger.info("-----retriveUserTest----- :: End --------");
	}

	/* RUNNING TEST CASE FOR GETTING STUDENT OF SPECIFIED YEAR */
	@Test
	@Ignore
	public void getUserbyDOB() {
		logger.info("-----User_DOB_Test----- :: Start --------");
		System.out.println("Enter Year of DOB : ");
		String year = sc.next();
		List<User> list = userManager.getUsersByDOB(year);
		if (list.size() > 0) {
			String userDob = list.get(0).getDOB();
			String userDOBYear = userDob.substring(0, 4);
			System.out.println("--------------------------");
			System.out.println("   Name  : DOB");
			System.out.println("--------------------------");
			for (User user : list) {
				System.out.println("  " + user.getName() + " : " + user.getDOB());
			}
			System.out.println("---------------------------");
			assertEquals("User date of birth not matching", userDOBYear, year);
		} else {
			System.out.println("No user found with DOB having year : " + year);
			logger.info("NO user found with DOB having year " + year);
		}

		logger.info("-----User_DOB_Test----- :: End --------");
	}

	@Test
	@Ignore
	public void getAllUsers() {
		logger.info("-----User_getAllUser_Test----- :: Start --------");
		List<User> users = userManager.getAll();
		System.out.println("-----------------------");
		System.out.println("ID : Name  :  DOB");
		System.out.println("-----------------------");
		for (User u : users) {
			System.out.println(u.getId() + " : " + u.getName() + " : " + u.getDOB());

			logger.info("-----User_getAllUser_Test----- :: End --------");
		}
		System.out.println("-----------------------");

	}

	/* Get Place Id By user */
	public int getPlaceIdByUser(int UserId) {
		int placeId = 0;
		List<User> users = userManager.getAll();

		for (User u : users) {
			if (u.getId() == UserId) {
				placeId = u.getPlace().getId();
			}
		}
		return placeId;
	}

	/* Get Events by place */
	public List<Event> getEventByPlace(int PlaceId) {
		List<Event> eventList = new ArrayList<Event>();
		List<Event> events = eventManager.getAll();
		System.out.println(events.size());
		if (events.size() == 0) {
			// eventList = null;
			System.out.println("----==== List is Empty =====----");
		} else {
			System.out.println("---------------------");
			System.out.println("ID : Name ");
			System.out.println("---------------------");
			for (Event e : events) {
				if (e.getPlaces().getId() == PlaceId) {
					eventList.add(e);
					System.out.println(e.getId() + " : " + e.getName());
				}
			}
		}

		return eventList;
	}

	/* Get Place by city */
	public Place getPlaceByCity(String city) {
		Place place = new Place();
		List<Place> places = placeManager.getAll();
		int flag = 0;
		for (Place p : places) {
			if (p.getCity().equals(city)) {
				place.setId(p.getId());
				place.setCity(p.getCity());
				flag = 0;
				break;
			} else {
				flag = 1;
			}
		}
		if (flag == 1) {
			noice = 1;
		}

		return place;
	}

	/*
	 * 
	 * Event
	 * 
	 **/
	@Test
	@Ignore
	public void saveEventTest() {
		logger.info("-----saveEventTest----- :: Start --------");

		Event event = UserTestHelper.getNewEvent();
		String newEvent = event.getName();
		System.out.println(event.getPlaces().getCity());
		System.out.println(newEvent + " issss");
		List<Event> eventList = eventManager.getAll();
		System.out.println("name of events : " + eventList.get(0).getName());
		int flag = 0;
		if (eventList.size() >= 1) {
			System.out.println(eventList.size() + "in >1 loop");
			for (int i = 0; i < eventList.size(); i++) {
				String DBEvent = eventList.get(i).getName();

				System.out.println(DBEvent);
				if (newEvent.equals(DBEvent)) {
					System.out.println(DBEvent + "is equal");
					assertEquals("Event Name not matching", newEvent, DBEvent);
					flag = 1;
				}
			}
			if (flag == 0) {
				System.out.println("is not equal");
				// eventManager.save(event);
			}

		} else {
			System.out.println("new user");
			// eventManager.save(event);
		}

		// assertNotNull("Event object has not been saved correctly.", event.getId());

		logger.info("-----saveEventTest----- :: End --------");
	}

	/* FOR DELETING DATABASE RECORDS */
	@Test
	@Ignore
	public void deleteEventTest() {
		logger.info("-----deleteEventTest----- :: Start --------");

		int eventId = 7;
		Event savedEvent = eventManager.getById(eventId);
		System.out.println(savedEvent.getName());
		eventManager.delete(savedEvent);
		assertNull("Event object has not been deleted correctly.", eventManager.getById(eventId));

		logger.info("-----deleteEventTest----- :: End --------");
	}

	@Ignore
	public List<Event> getAllEvents() {
		logger.info("-----User_getAllEvent_Test----- :: Start --------");
		List<Event> events = eventManager.getAll();
		System.out.println("-----------------------");
		System.out.println("ID : Name  ");
		System.out.println("-----------------------");
		for (Event e : events) {
			System.out.println(e.getId() + " : " + e.getName());
		}
		System.out.println("-----------------------");
		logger.info("-----User_getAllEvent_Test----- :: End --------");
		return events;

	}

	/* FOR UPDATING PARTICULAR RECORDS */
	@Test
	@Ignore
	public void updateEventTest() {

		// logger.info("-----updateEventtTest----- :: Start --------");
		System.out.println("------------------------");
		System.out.println("      Update Mode");
		System.out.println("------------------------");

		List<Event> events = getAllEvents();

		int eventId;
		String eventName = "";
		System.out.println("Enter Event ID : ");
		eventId = sc.nextInt();
		String buff = sc.nextLine();

		Event savedEvent = eventManager.getById(eventId);

		int inFlag = 0;
		Boolean failMsg = false;
		for (Event event : events) {
			if (event.getId() == eventId) {
				inFlag = 1;
				failMsg = false;
				break;
			} else {
				failMsg = true;
			}
		}
		if (inFlag == 1) {
			System.out.println("Enter New Event Name : ");
			eventName = sc.nextLine();
			savedEvent.setName(eventName);
			eventManager.save(savedEvent);
			System.out.println("Event Updated");
		}
		if (failMsg == true) {
			System.out.println("Event ID not Found.");
		}

		Event updatedEvent = eventManager.getById(eventId);

		String updateEventName = updatedEvent.getName();
		assertEquals(eventName, updateEventName);
		assertNotNull("event object has not been updated correctly.", savedEvent);
		logger.info("-----updateEventTest----- :: End --------");
	}

	/*
	 * 
	 * Place
	 * 
	 **/
	@Test
	@Ignore
	public void savePlaceTest() {
		// logger.info("-----savePlaceTest----- :: Start --------");

		Place place = UserTestHelper.getNewPlace();
		System.out.println(place.getCity());
		placeManager.save(place);
//		String placeOfEvent = place.getCity();
//		List<Place> placeList = placeManager.getAll();
//
//		int flag = 0;
//		if (placeList.size() >= 1) {
//			System.out.println(placeList.size() + "in >1 loop");
//			for (int i = 0; i < placeList.size(); i++) {
//				String DBPlace = placeList.get(i).getCity();
//
//				System.out.println(DBPlace);
//				if (placeOfEvent.toLowerCase().equals(DBPlace.toLowerCase())) {
//					// System.out.println(DBPlace + " is equal");
//					flag = 1;
//					assertEquals("Event Name not matching", placeOfEvent, DBPlace);
//					continue;
//				}
//			}
//			if (flag == 0) {
//				System.out.println("is not equal");
//				placeManager.save(place);
//			}
//
//		} else {
//			System.out.println("new user");
//			placeManager.save(place);
//		}

//		assertNotNull("Place object has not been saved correctly.", place.getId());
//
//		logger.info("-----savePlaceTest----- :: End --------");
	}

	/* FOR DELETING DATABASE RECORDS */

	@Test
	@Ignore
	public void deletePlaceTest() {
		logger.info("-----deletePlaceTest----- :: Start --------");

		int placeId = 4;
		Place place = placeManager.getById(placeId);
		System.out.println(place.getCity());
		placeManager.delete(place);
		assertNull("Place object has not been deleted correctly.", place.getId());

		logger.info("-----deletePlaceTest----- :: End --------");
	}

	@Ignore
	public List<Place> getAllPlaces() {
		logger.info("-----User_getAllPlace_Test----- :: Start --------");
		List<Place> places = placeManager.getAll();
		System.out.println("-----------------------");
		System.out.println("ID : City  ");
		System.out.println("-----------------------");
		for (Place place : places) {
			System.out.println(place.getId() + " : " + place.getCity());
		}
		System.out.println("-----------------------");
		logger.info("-----User_getAllPlace_Test----- :: End --------");
		return places;

	}

	@Test
	@Ignore
	public void updatePlaceTest() {

		logger.info("-----updatePlacetTest----- :: Start --------");
		System.out.println("------------------------");
		System.out.println("      Update Mode");
		System.out.println("------------------------");

		List<Place> places = getAllPlaces();

		int placeId;
		String cityOfPlace = "";
		System.out.println("Enter Place ID : ");
		placeId = sc.nextInt();
		String buff = sc.nextLine();

		Place savedPlace = placeManager.getById(placeId);
		assertNotNull("Place object has not been saved correctly.", savedPlace);

		int inFlag = 0;
		Boolean failMsg = false;
		for (Place place : places) {
			if (place.getId() == placeId) {
				inFlag = 1;
				failMsg = false;
				break;
			} else {
				failMsg = true;
			}
		}
		if (inFlag == 1) {
			System.out.println("Enter New City of Place : ");
			cityOfPlace = sc.nextLine();
			savedPlace.setCity(cityOfPlace);
			placeManager.save(savedPlace);
			System.out.println("Place Updated");
		}
		if (failMsg == true) {
			System.out.println("Place ID not Found.");
		}

		Place updatedPlace = placeManager.getById(placeId);

		String updatePlaceName = updatedPlace.getCity();
		assertEquals(cityOfPlace, updatePlaceName);
		assertNotNull("Place object has not been updated correctly.", savedPlace);
		logger.info("-----updatePlaceTest----- :: End --------");
	}

	@Test
	@Ignore
	public void getRelatedData() {
		Scanner sc = new Scanner(System.in);
		getAllUsers();

		int userId;
		System.out.println("Enter your ID : ");
		userId = sc.nextInt();

		System.out.println(userId);

		int placeId = getPlaceIdByUser(userId);
		System.out.println(placeId);

		getEventByPlace(placeId);

	}

	@Test
	@Ignore
	public void setDataDynamically() {

		User user = new User();
		System.out.println("Enter your Name : ");
		String UserName, DOB, City;
		UserName = sc.nextLine();
		System.out.println("Enter your DateOfBirth in this formate-yyyy-mm-dd: ");
		DOB = sc.nextLine();
		user.setName(UserName);
		user.setDOB(DOB);

		System.out.println("Enter your city : ");
		City = sc.nextLine();

		Place place = getPlaceByCity(City);

		if (noice == 0) {
			user.setPlace(place);

			List<Event> eventList = getEventByPlace(place.getId());

			if (!eventList.isEmpty()) {
				System.out.println("Enter Event id which u want to enroll!");
				int eId = sc.nextInt();

				int innerFlag = 0;
				for (Event et : eventList) {
					if (et.getId() == eId) {
						userManager.save(user);
						break;
					} else {
						innerFlag = 1;
					}
				}
				if (innerFlag == 1) {

					System.out.println("-------------------------------------");
					System.out.println("      You entered wrong event Id ");
					System.out.println("      Program execution stopped  ");
					System.out.println("-------------------------------------");

				}

			} else {
				System.out.println("-------------------------------------");
				System.out.println("  Events Not available in your city");
				System.out.println("-------------------------------------");
			}

		} else {
			System.out.println("-------------------------------------");
			System.out.println("  Events Not available in your city");
			System.out.println("-------------------------------------");
		}

	}

}
