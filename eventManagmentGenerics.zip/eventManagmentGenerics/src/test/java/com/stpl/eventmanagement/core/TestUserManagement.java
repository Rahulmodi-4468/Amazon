package com.stpl.eventmanagement.core;

import static org.junit.Assert.*;

import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.stpl.eventmanagement.core.bean.Event;
import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.core.bean.User;

@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class TestUserManagement extends BaseManagerTest {

	private static final Logger logger = Logger.getLogger(TestUserManagement.class);

	/* FOR SAVING RECORD IN DATABASE */

	@Test
	@Ignore
	public void saveUserTest() {
		logger.info("-----saveUserTest----- :: Start --------");

		User user = UserTestHelper.getNewUser();
		String oldUser = user.getName();

//		List<User> userList = userManager.getAll();
//
//		int flag = 0;
//		if ((userList.size()) == 1 && (userList.get(0).getName().equals(oldUser))) {
//			System.out.println("User already available.");
//		} else if (userList.size() > 1) {
//			System.out.println(userList.size() + "in >1 loop");
//			for (int i = 0; i < userList.size(); i++) {
//				String newName = userList.get(i).getName();
//				System.out.println(newName);
//				if (oldUser.equals(newName)) {
//					System.out.println(newName + "is equal");
//					flag = 1;
//				}
//			}
//			if (flag == 0) {
//				System.out.println("is not equal");
//				userManager.save(user);
//			}
//
//		} else {
//			System.out.println("new user");
//			userManager.save(user);
//		}
		 userManager.save(user);
		assertNotNull("User object has not been saved correctly.", user.getId());
		User savedUser = userManager.getById(user.getId());
		assertEquals("Both User ids are not equals", user.getId(), savedUser.getId());
		assertEquals("Both User names are not equals", user.getName(), savedUser.getName());
		logger.info("-----saveUserTest----- :: End --------");
	}

	/* FOR DELETING DATABASE RECORDS */
	@Test
	@Ignore
	public void deleteUserTest() {
		logger.info("-----deleteUserTest----- :: Start --------");

		int userId = 27;
		User savedUser = userManager.getById(userId);
		System.out.println("---"+savedUser.getDOB()+"---"+savedUser.getName());
		userManager.delete(savedUser);
		assertNull("User object has not been deleted correctly.", userManager.getById(userId));

		logger.info("-----deleteUserTest----- :: End --------");
	}

	/* FOR UPDATING PARTICULAR RECORDS */
	@Test
	@Ignore
	public void updateUserTest() {
		System.out.println("in");
		logger.info("-----updateUsertTest----- :: Start --------");
		int userId = 4;
		String userName = "Ravi";
		User savedUser = userManager.getById(userId);
		assertNotNull("User object has not been saved correctly.", savedUser);
		System.out.println("savedStudent" + savedUser.getDOB());

		savedUser.setName(userName);
		userManager.save(savedUser);

		User updatedUser = userManager.getById(userId);

		String updateUserName = updatedUser.getName();
		assertEquals(userName, updateUserName);
		assertNotNull("User object has not been updated correctly.", savedUser);

		logger.info("-----updateUserTest----- :: End --------");
	}

	/* RETRIVING PARTICULAR RECORD FROM DATABASE */
	@Test
	@Ignore
	public void retriveStudentTest() {
		logger.info("-----retriveUserTest----- :: Start --------");
		int userId = 1;
		User savedUser = userManager.getById(userId);
		System.out.println(savedUser.getName());
		assertNotNull("User object has not been saved correctly.", savedUser);
		logger.info("-----retriveUserTest----- :: End --------");
	}

	/* RUNNING TEST CASE FOR GETTING STUDENT OF SPECIFIED YEAR */
	@Test
	@Ignore
	public void getUserbyDOB() {
		logger.info("-----User_DOB_Test----- :: Start --------");
		String year = "1999";
		List<User> list = userManager.getUsersByDOB(year);
		System.out.println("UsEr -->" + list.get(0).getName());
		if (list.size() > 0) {
			String userDob = list.get(0).getDOB();
			String userDOBYear = userDob.substring(0, 4);
			assertEquals("User date of birth not matching", userDOBYear, year);
		} else {
			logger.info("NO user found with DOB having year " + year);
		}

		logger.info("-----User_DOB_Test----- :: End --------");
	}

	@Test
	@Ignore
	public void getAllData() {
		logger.info("-----User_getAllData_Test----- :: Start --------");
		List<User> users = userManager.getAll();

		for (User u : users) {
			System.out.println(u);

			logger.info("-----User_getAllData_Test----- :: End --------");
		}

	}

	/*
	 * 
	 * Event
	 * 
	 **/
	@Test
	//@Ignore
	public void saveEventTest() {
		logger.info("-----saveEventTest----- :: Start --------");

		Event event = UserTestHelper.getNewEvent();

		eventManager.save(event);
		assertNotNull("Event object has not been saved correctly.", event.getId());
		
		logger.info("-----saveEventTest----- :: End --------");
	}
	@Test
	//@Ignore
	public void savePlaceTest() {
		logger.info("-----savePlaceTest----- :: Start --------");

		Place place = UserTestHelper.getNewPlace();
		System.out.println(place.getCity());
		placeManager.save(place);
		assertNotNull("Place object has not been saved correctly.", place.getId());

		logger.info("-----savePlaceTest----- :: End --------");
	}

}
