package com.stpl.eventmanagement.core.dao;

import java.util.List;

import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.persistence.IEntityDAO;

public interface IPlaceDAO extends IEntityDAO<Place>{
	public List<Place> getOfCity(String name); 
}
