package com.stpl.eventmanagement.core.controller;

import java.util.List;

import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.core.dao.IUserDAO;
import com.stpl.eventmanagement.persistence.EntityManager;


public class UserManager extends EntityManager<User, IUserDAO> implements IUserManager  {

	@Override
	public List<User> getUsersByDOB(String year) {
		return  dao.getUsersByDOB(year);
	
	}

	@Override
	public List<User> getUsersByName(String name) {
		return  dao.getUsersByName(name);
	}


	

}
