package com.stpl.eventmanagement.core.controller;

import java.util.List;

import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.core.dao.IUserDAO;
import com.stpl.eventmanagement.persistence.EntityManager;


public class UserManager extends EntityManager<User, IUserDAO> implements IUserManager  {

	
	public List<User> getUsersByDOB(String year) {
		System.out.println("InUserManager");
		return dao.getUsersByDOB(year);
	
	}


	public List<User> getUsersByName(String name) {
		return dao.getUsersByName(name);
	}

//	public Boolean checker(List<User> userList,String oldUser) {
//		return dao.checker(userList,oldUser);
//	}
//	

}
