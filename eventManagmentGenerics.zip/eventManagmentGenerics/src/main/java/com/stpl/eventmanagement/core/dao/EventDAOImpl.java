package com.stpl.eventmanagement.core.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.stpl.eventmanagement.core.bean.Event;
import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.persistence.EntityDAOImpl;

public class EventDAOImpl extends EntityDAOImpl<Event> implements IEventDAO {

	private static final Logger logger = Logger.getLogger(EventDAOImpl.class);

	@Override
	@SuppressWarnings("unchecked")
	public List<Event> getEventsByCityName(String city) {
		List<Event> event = new ArrayList<Event>();
		if (logger.isTraceEnabled()) {
			logger.trace("getById(ObjectId) - start");
		}

		event = (List<Event>) getHibernateTemplate().get(Event.class, city);
		if (logger.isTraceEnabled()) {
			logger.trace("getById(ObjectId) - end");
		}
		return event;
	}


	@Override
	public Class<Event> getTargetClass() {
		return Event.class;
	}

}
