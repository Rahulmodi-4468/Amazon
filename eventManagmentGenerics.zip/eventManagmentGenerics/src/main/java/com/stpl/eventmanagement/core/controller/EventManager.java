package com.stpl.eventmanagement.core.controller;


import com.stpl.eventmanagement.core.bean.Event;
import com.stpl.eventmanagement.core.dao.IEventDAO;
import com.stpl.eventmanagement.persistence.EntityManager;

public class EventManager extends EntityManager<Event, IEventDAO> implements IEventManager {

	@Override
	public Event getById(int eventId) {
		return dao.getById(eventId);
	}




//	@Override
//	public List<Event> getEventsByName(String name) {
//		// TODO Auto-generated method stub
//		return null;
//	}


}
