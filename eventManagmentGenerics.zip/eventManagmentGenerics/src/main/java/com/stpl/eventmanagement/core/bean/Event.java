package com.stpl.eventmanagement.core.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "event")
public class Event {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Integer id;
	private String name;
	

	@ManyToOne//(cascade = CascadeType.REFRESH)
	private Place place;

	public Place getPlaces() {
		return place;
	}

	public void setPlaces(Place places) {
		this.place = places;
	}

	public Integer getId() {
		return id;
	}

	@Column(name = "name")
	public String getName() {
		return name;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}


}
