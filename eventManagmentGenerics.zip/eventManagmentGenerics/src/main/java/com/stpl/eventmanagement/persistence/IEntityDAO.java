package com.stpl.eventmanagement.persistence;

import java.util.List;

import com.stpl.eventmanagement.core.bean.User;


public interface IEntityDAO<IEntityType> {
	
	public void save(IEntityType record);
    public IEntityType getById(Integer id);
    public List<IEntityType> getAll();
    public void delete(IEntityType entity);
//	public List<User> getUsersByDOB(String year);
//	public List<User> getUsersByName(String name);
	public Boolean checker(List<User> userList,String oldUser);
	//public List<User> getUsersByDOB(String year);
}
