package com.stpl.eventmanagement.core.controller;


import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.core.dao.IPlaceDAO;
import com.stpl.eventmanagement.persistence.EntityManager;



public class PlaceManager extends EntityManager<Place, IPlaceDAO> implements IPlaceManager{
	
	protected IPlaceDAO dao;
	public void setPlaceDao(IPlaceDAO dao) {
		this.dao = dao;
	}

	public IPlaceDAO getPlaceDao() {
		return dao;
	}


	public Place getById(Integer id) {
		 Place returnIEntityType = (Place) getPlaceDao().getById(id);   
	     return returnIEntityType;
	}

	
}


