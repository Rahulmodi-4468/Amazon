package com.stpl.eventmanagement.core.dao;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.persistence.EntityDAOImpl;

public class UserDAOImpl extends EntityDAOImpl<User> implements IUserDAO {
	private static final Logger logger = Logger.getLogger(UserDAOImpl.class);

	@Override
	public Class<User> getTargetClass() {
		return User.class;
	}

	public List<User> getUsersByDOB(String year) {
		Session currentSession = getHibernateTemplate().getSessionFactory().getCurrentSession();
		String sql = "SELECT * FROM eventdb.user WHERE DOB = " + year;
		SQLQuery query = currentSession.createSQLQuery(sql);
		query.addEntity(User.class);

		@SuppressWarnings("unchecked")
		List<User> results = query.list();
		return results;
	}

	/*
	 * This class will fetch the employees for particular name specified by the user
	 */
	public List<User> getUsersByName(String name) {
		Session currentSession = getHibernateTemplate().getSessionFactory().getCurrentSession();
		String sql = "SELECT * FROM eventdb.user WHERE name = " + name;
		SQLQuery query = currentSession.createSQLQuery(sql);
		query.addEntity(User.class);

		@SuppressWarnings("unchecked")
		List<User> results = query.list();
		return results;
	}

//	@SuppressWarnings("unchecked")
//	@Override
//	public List<User> getAll() {
//		
//		if (logger.isTraceEnabled()) {
//			logger.trace("getAll() - start");
//		}
//		Criteria criteria = getSession(false).createCriteria(User.class);
//		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
//		List<User> returnList= criteria.list();
//		if (logger.isTraceEnabled()) {
//			logger.trace("getAll() - end");
//		}
//
//		return returnList;
//
//	}
}
