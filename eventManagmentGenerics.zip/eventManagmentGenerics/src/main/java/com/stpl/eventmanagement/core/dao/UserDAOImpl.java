package com.stpl.eventmanagement.core.dao;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.persistence.EntityDAOImpl;

public class UserDAOImpl extends EntityDAOImpl<User> implements IUserDAO {
	private static final Logger logger = Logger.getLogger(UserDAOImpl.class);

	@Override
	public Class<User> getTargetClass() {
		return User.class;
	}

	public List<User> getUsersByDOB(String year) {
		Session currentSession = getHibernateTemplate().getSessionFactory().getCurrentSession();
		String sql = "SELECT * FROM eventdb.user WHERE DOB LIKE '" + year + "%'";
		SQLQuery query = currentSession.createSQLQuery(sql);
		query.addEntity(User.class);

		@SuppressWarnings("unchecked")
		List<User> results = query.list();
		System.out.println(results.size());
		return results;
	}

	/*
	 * This class will fetch the employees for particular name specified by the user
	 */
	public List<User> getUsersByName(String name) {
		Session currentSession = getHibernateTemplate().getSessionFactory().getCurrentSession();
		String sql = "SELECT * FROM eventdb.user WHERE name = " + name;
		SQLQuery query = currentSession.createSQLQuery(sql);
		query.addEntity(User.class);

		@SuppressWarnings("unchecked")
		List<User> results = query.list();
		return results;
	}

//	public Boolean checker(List<User> userList,String oldUser) {
//		System.out.println("In checker");
//		Boolean flag = true;
//		if (userList.size() >= 1) {
//			System.out.println(userList.size() + "in >1 loop");
//			for (int i = 0; i < userList.size(); i++) {
//				String DBUser = userList.get(i).getName();
//				
//				System.out.println(DBUser);
//				if (oldUser.equals(DBUser)) {
//					System.out.println(DBUser + "is equal");
//					//assertEquals("USer Name not matching", oldUser, DBUser);
//					flag = false;
//				}
//			}
//			if (flag == true) {
//				System.out.println(" is not equal");
//				flag = true;
//				//userManager.save(user);
//			}
//
//		} 
//		else {
//			System.out.println("new user");
//			//userManager.save(user);
//			flag = true;
//		}
//		return flag;
//	}
//	@SuppressWarnings("unchecked")
//	@Override
//	public List<User> getAll() {
//		
//		if (logger.isTraceEnabled()) {
//			logger.trace("getAll() - start");
//		}
//		Criteria criteria = getSession(false).createCriteria(User.class);
//		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
//		List<User> returnList= criteria.list();
//		if (logger.isTraceEnabled()) {
//			logger.trace("getAll() - end");
//		}
//
//		return returnList;
//
//	}
}
