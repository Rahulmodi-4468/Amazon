package com.stpl.eventmanagement.core.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.persistence.EntityDAOImpl;


public class PlaceDAOImpl extends EntityDAOImpl<Place> implements IPlaceDAO{

	private static final Logger logger = Logger.getLogger(PlaceDAOImpl.class);

	@Override
	public Class<Place> getTargetClass() {
		return Place.class;
	}


	@Override
	public List<Place> getOfCity(String name) {
		// TODO Auto-generated method stub
		return null;
	}




	
}
