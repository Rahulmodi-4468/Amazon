package com.stpl.eventmanagement.core.controller;

import com.stpl.eventmanagement.core.bean.Event;
import com.stpl.eventmanagement.persistence.IEntityManager;

public interface IEventManager extends IEntityManager<Event>{

//	public Event getById(int eventId);
}
