package com.stpl.eventmanagement.core.controller;

import com.stpl.eventmanagement.core.bean.Event;
import com.stpl.eventmanagement.persistence.IEntityManager;

public interface IEventManager extends IEntityManager<Event>{

//	public void save(Event e);
//	public void delete(Event record);
	public Event getById(int eventId);
//	public List<Event> geteventsByCityName(String city); 
//	
}
