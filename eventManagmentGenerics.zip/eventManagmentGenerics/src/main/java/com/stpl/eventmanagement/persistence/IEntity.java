package com.stpl.eventmanagement.persistence;

public interface IEntity {

}
