package com.stpl.eventmanagement.core.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="place")
public class Place {
	
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String city;
	
	@OneToMany(mappedBy="place")//,cascade= {CascadeType.ALL})
	private List<User> user = new ArrayList<User>();
	
	@OneToMany(mappedBy="place")//,cascade= {CascadeType.ALL})
	private List<Event> event = new ArrayList<Event>();
	
	
	public List<User> getUser() {
		return user;
	}
	public void setUser(List<User> user) {
		this.user = user;
	}
	public List<Event> getEvent() {
		return event;
	}
	public void setEvent(List<Event> event) {
		this.event = event;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String string) {
		this.city = string;
	}
	
	


}
