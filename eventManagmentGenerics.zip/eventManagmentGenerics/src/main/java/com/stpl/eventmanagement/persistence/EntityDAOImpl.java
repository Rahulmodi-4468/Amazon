package com.stpl.eventmanagement.persistence;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.stpl.eventmanagement.core.bean.User;

public abstract class EntityDAOImpl<IEntityType> extends HibernateDaoSupport implements IEntityDAO<IEntityType> {

	private static final Logger logger = Logger.getLogger(EntityDAOImpl.class);

	private final Class<IEntityType> type;
	protected ApplicationContext applicationContext;

	public EntityDAOImpl() {
		type = getTargetClass();
	}

	public void save(IEntityType record) {
		if (logger.isTraceEnabled()) {
			logger.trace("save(IEntityType) - start");
		}
		getHibernateTemplate().saveOrUpdate(record);
		System.out.println("daoimpsave");
		if (logger.isTraceEnabled()) {
			logger.trace("save(IEntityType) - end");
		}
	}

	public IEntityType getById(Integer id) {
		if (logger.isTraceEnabled()) {
			logger.trace("getById(ObjectId) - start");
		}

		IEntityType returnIEntityType = (IEntityType) getHibernateTemplate().get(type, id);
		System.out.println("daoimpgetbyid");
		if (logger.isTraceEnabled()) {
			logger.trace("getById(ObjectId) - end");
		}
		return returnIEntityType;
	}

	public abstract Class<IEntityType> getTargetClass();

	@SuppressWarnings("unchecked")
	@Override
	public List<IEntityType> getAll() {
		if (logger.isTraceEnabled()) {
			logger.trace("getAll() - start");
		}

		Criteria criteria = getSession(false).createCriteria(getTargetClass());
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		List<IEntityType> returnList = criteria.list();
		if (logger.isTraceEnabled()) {
			logger.trace("getAll() - end");
		}
		return returnList;
	}

	public void delete(User entity) {
		if (logger.isTraceEnabled()) {
			logger.trace("delete(IEntityType) - start");
		}

		getHibernateTemplate().delete(entity);
		System.out.println("daoimpdelete");
		if (logger.isTraceEnabled()) {
			logger.trace("delete(IEntityType) - end");
		}
	}

}
