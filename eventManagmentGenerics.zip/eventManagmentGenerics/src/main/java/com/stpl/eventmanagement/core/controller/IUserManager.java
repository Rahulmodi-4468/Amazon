package com.stpl.eventmanagement.core.controller;
import java.util.List;

import com.stpl.eventmanagement.core.bean.User;
import com.stpl.eventmanagement.persistence.IEntityManager;

public interface IUserManager extends IEntityManager<User> {
	List<User> getUsersByDOB(String year);
	public List<User> getUsersByName(String name);
	List<User> getAll();
}
