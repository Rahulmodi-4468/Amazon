package com.stpl.eventmanagement.core.controller;

import com.stpl.eventmanagement.core.bean.Place;
import com.stpl.eventmanagement.persistence.IEntityManager;

public interface IPlaceManager extends IEntityManager<Place> {

}
