package com.stpl.eventmanagement.persistence;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;


@Transactional
public abstract class EntityManager<IEntityType, IEntityDAOType extends IEntityDAO<IEntityType>> implements IEntityManager<IEntityType> {
    /**
     * Logger for this class
     */
    private static final Logger logger = Logger.getLogger(EntityManager.class);
    protected IEntityDAO<IEntityType> dao;

    public IEntityDAO getEntityDAO() {
        return dao;
    }

    public void setEntityDAO(IEntityDAO dao) {
        this.dao = dao;
    }

    @Override
    @Transactional(readOnly = false)
    public void save(IEntityType record) {
        if (logger.isTraceEnabled()) {
            logger.trace("save(IEntityType) - start");
        }
       
        getEntityDAO().save(record);
        System.out.println("managersave");
        if (logger.isTraceEnabled()) {
            logger.trace("save(IEntityType) - end");
        }
    }

	@Override
    public IEntityType getById(Integer id) {
        if (logger.isTraceEnabled()) {
            logger.trace("getById(ObjectId) - start");
        }

        IEntityType returnIEntityType = (IEntityType) getEntityDAO().getById(id);
        System.out.println("managergetbyid");
        if (logger.isTraceEnabled()) {
            logger.trace("getById(ObjectId) - end");
        }
        return returnIEntityType;
    }
    
    
    public List<IEntityType> getAll() {
        if (logger.isTraceEnabled()) {
            logger.trace("getAll() - start");
        }
        List<IEntityType> returnList = getEntityDAO().getAll();
        System.out.println("managergetall");
        if (logger.isTraceEnabled()) {
            logger.trace("getAll() - end");
        }
        return returnList;
    }

    @Override
    @Transactional(readOnly = false)
    public void delete(IEntityType record) {
        if (logger.isTraceEnabled()) {
            logger.trace("delete(IEntityType) - start");
        }

        getEntityDAO().delete(record);
        System.out.println("managerdelete");
        if (logger.isTraceEnabled()) {
            logger.trace("delete(IEntityType) - end");
        }
    }

}
